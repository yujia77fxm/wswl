package com.wswl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@MapperScan("")
@SpringBootApplication
public class WalletBootApplication {
    public static void main(String[] args) {
        SpringApplication.run(WalletBootApplication.class, args);
    }
}
