package com.wswl.service.impl;

import com.wswl.dao.AccoutMapper;
import com.wswl.service.AccoutService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class AccoutServiceImpl implements AccoutService {

    @Autowired
    private AccoutMapper accoutMapper;



    @Override
    public String getAdress() {


        String getAdress = "getAdress";

        accoutMapper.insert();

        return getAdress;
    }
}
