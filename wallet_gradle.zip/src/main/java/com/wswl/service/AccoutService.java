package com.wswl.service;

public interface AccoutService {

    String getAdress();
}
