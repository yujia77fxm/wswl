package com.wswl.controller;


import com.wswl.service.AccoutService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * 获得地址
 */
@RequestMapping("/adress")
@RestController
public class AccoutController {

    @Autowired
    private AccoutService accoutService;

    @PostMapping("/ss")
    public ResponseEntity getAdress() {
        return ResponseEntity.status(HttpStatus.FOUND).body(accoutService.getAdress());
    }
}
