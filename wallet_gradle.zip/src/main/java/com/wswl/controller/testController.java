package com.wswl.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.tron.common.utils.Utils;
import org.tron.core.exception.CancelException;
import org.tron.core.exception.CipherException;
import org.tron.protos.Protocol;
import org.tron.walletcli.WalletApiWrapper;
import org.tron.walletserver.WalletApi;

import java.io.IOException;

@RestController
public class testController {
    @GetMapping
    public String hello(){
         WalletApiWrapper walletApiWrapper = new WalletApiWrapper();
        String address = "TWbcHNCYzqAGbrQteKnseKJdxfzBHyTfuh";
        byte[] addressBytes = WalletApi.decodeFromBase58Check(address);
        if (addressBytes == null) {
            return "address parameter not available!! ";
        }

        Protocol.Account account = WalletApi.queryAccount(addressBytes);
        if (account == null) {
            System.out.println("GetAccount failed !!!!");
            return "account == null----";
        } else {
            System.out.println(Utils.formatMessageString(account));
            return account.toString() + "  show account";
        }
    }


    private void createAccount(String[] parameters)
            throws CipherException, IOException, CancelException {

        WalletApiWrapper walletApiWrapper = new WalletApiWrapper();
        if (parameters == null || (parameters.length != 1 && parameters.length != 2)) {
            System.out.println("CreateAccount needs 1 parameter using the following syntax: ");
            System.out.println("CreateAccount [OwnerAddress] Address");
            return;
        }

        int index = 0;
        byte[] ownerAddress = null;
        if (parameters.length == 2) {
            ownerAddress = WalletApi.decodeFromBase58Check(parameters[index++]);
            if (ownerAddress == null) {
                System.out.println("Invalid OwnerAddress.");
                return;
            }
        }

        byte[] address = WalletApi.decodeFromBase58Check(parameters[index++]);
        if (address == null) {
            System.out.println("Invalid Address.");
            return;
        }

        boolean result = walletApiWrapper.createAccount(ownerAddress, address);
        if (result) {
            System.out.println("CreateAccount successful !!");
        } else {
            System.out.println("CreateAccount failed !!");
        }
    }
}
